import React from 'react';
import { CircularProgress, Container, Alert, Typography, Box, Button, TextField, Snackbar } from '@mui/material';
import { Link, useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useFormik } from 'formik';
import * as yup from 'yup';

// const validationSchema = yup.object({
//     email : yup.string().required().email(),
//     first_name: yup.string().required().min(5),
//     last_name: yup.string().required().min(5),
//     password: yup.string().required().matches(
//         /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
//         "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
//     ),
// });

const validationSchema = yup.object({
    email : yup.string().required().email(),
    first_name: yup.string().required().min(5),
    last_name: yup.string().required().min(5).max(5)
});

/**
 * --------------------------------------
 * form with formik and yup.
 * --------------------------------------
 */

export default function Form() {
    const { id } = useParams();
    
    let navigate = useNavigate();

    let udata = localStorage.getItem('usersData')?.split(',  ').map((u)=> JSON.parse(u));    
    let tdata = udata.filter((ud) => {
        return ud.id == id;
    });
    console.log(tdata);
    const l_id = Array.isArray(udata) ? udata[udata.length - 1].id : 0;

    const formik = useFormik({
        initialValues: {
            email: tdata[0] ? tdata[0].email : '',
            first_name: tdata[0] ? tdata[0].first_name : '',
            last_name: tdata[0] ? tdata[0].last_name : ''
        },
        validationSchema: validationSchema,
        onSubmit: (values) => {
            if(id) {
                console.log("values : ", values);
                console.log("update : ", {...tdata[0], ...values});
                udata = udata.map((u) => u.id == id ? {...tdata[0], ...values} : u );
                // udata.push({...values, id : (l_id + 1)}); // temp
                // udata = [...udata, {...values, id : id}];
            }else {
                console.log("new added : ", { id : (l_id + 1), ...values});
                udata.push({ id : (l_id + 1), ...values});
            }
            console.log(udata);
            localStorage.setItem(
                'usersData', 
                udata.map((d) => JSON.stringify(d)).join(',  ')
            );

            navigate('/', { replace: true });
        }
    });

    

    React.useEffect(() => {
        // console.log(id);
        // if(typeof id !== 'undefined') {
        if(id) {
            (async function () {
                
                // ==== new api
                // let { data } = await axios.get(`https://random-data-api.com/api/users/random_user?id=${id}`);      
                // setEData(data);
    
                // ==== old api
                // let { data } = await axios.get(`https://reqres.in/api/users/${id}`);
                // formik.values = data.data;
                // console.log(data.data);

                // let temp = udata.split(',  ').map((u)=> JSON.parse(u));
                console.log("Adf");
                // formik.initialValues ={
                //     email: 'afasdf',
                //     first_name: 'adsfadsf',
                //     last_name: 'asdf'
                // } ;
            })();
        }
    }, []);

    return (
        <Container maxWidth="sm" >
            <Box sx={{
                    my: 8,
                    mx: 4,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    color: '#fff'
                }} >
                <Typography component="h1" variant="h5">
                    {id ? "Update" : "Add"} Details
                </Typography>
                <Box component="form" noValidate onSubmit={formik.handleSubmit} sx={{ mt: 1 }}>
                {/* <TextField
                    fullWidth
                    id="email"
                    name="email"
                    label="Email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    error={formik.touched.email && Boolean(formik.errors.email)}
                    helperText={formik.touched.email && formik.errors.email}
                />                 */}
                <TextField
                    InputProps={{ sx: { color: '#fff' } }}
                    margin="normal"
                    required
                    fullWidth
                    id="email"
                    label="Email Address"
                    name="email"
                    autoComplete="email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    error={formik.touched.email && Boolean(formik.errors.email)}
                    helperText={formik.touched.email && formik.errors.email}
                    autoFocus
                />

                <TextField
                    InputProps={{ sx: { color: '#fff' } }}
                    margin="normal"
                    required
                    fullWidth
                    id="first_name"
                    label="First Name"
                    name="first_name"
                    value={formik.values.first_name}
                    onChange={formik.handleChange}
                    error={formik.touched.first_name && Boolean(formik.errors.first_name)}
                    helperText={formik.touched.first_name && formik.errors.first_name}
                    autoComplete="first_name"
                />

                <TextField
                    InputProps={{ sx: { color: '#fff' } }}
                    margin="normal"
                    required
                    fullWidth
                    id="last_name"
                    label="Last Name"
                    name="last_name"
                    value={formik.values.last_name}
                    onChange={formik.handleChange}
                    error={formik.touched.last_name && Boolean(formik.errors.last_name)}
                    helperText={formik.touched.last_name && formik.errors.last_name}
                    autoComplete="last_name"
                /> 

                <Button
                    type="submit"
                    fullWidth
                    size="large"
                    variant="contained"
                    sx={{ mt: 3, mb: 2, width: "max-content" }}
                >
                {id ? "Update" : "Add"}
                </Button>
                <Link to="/">
                    <Button
                        type="submit"
                        fullWidth
                        size="large"    
                        variant="outlined"
                        color="info"
                        sx={{ mt: 3, ml: 2, mb: 2, width: "max-content" }}
                        >
                        Back
                    </Button>
                </Link>
                </Box>
                
        </Box>
                {/* <pre> {JSON.stringify(formik, null, 2)} </pre> */}

        </Container>
    );
}